/* ==========================================================================
   REPENT — app.js
   All data lives in localStorage under 'repent_v1'.
   Canonical storage units (never change, regardless of display units):
     - body weight, weigh-ins  -> kilograms
     - running distance        -> miles
     - lifting load            -> pounds
   Display conversion happens only at render time via fmtWeight()/fmtDist().
   ========================================================================== */

(function () {
  "use strict";

  const STORAGE_KEY = "repent_v1";

  const KG_PER_LB = 0.45359237;
  const MI_PER_KM = 0.621371;
  const lbToKg = (lb) => lb * KG_PER_LB;
  const kgToLb = (kg) => kg / KG_PER_LB;
  const kmToMi = (km) => km * MI_PER_KM;

  const uid = () => Math.random().toString(36).slice(2, 10) + Date.now().toString(36);
  // Local-calendar-date string (yyyy-mm-dd), deliberately NOT toISOString()
  // (which converts to UTC and would shift the date for any timezone ahead
  // or behind UTC, e.g. showing "yesterday" during early-morning hours).
  function localDateStr(d) {
    const y = d.getFullYear();
    const m = String(d.getMonth() + 1).padStart(2, "0");
    const day = String(d.getDate()).padStart(2, "0");
    return `${y}-${m}-${day}`;
  }
  const todayStr = () => localDateStr(new Date());
  const clamp = (n, lo, hi) => Math.max(lo, Math.min(hi, n));

  // ---------------------------------------------------------------------
  // STATE
  // ---------------------------------------------------------------------
  const defaultState = {
    profile: { units: "imperial", weightKg: null, name: "" },
    sleep: [],    // {id, date, bedtime, wake, hours, quality}
    exercise: [], // {id, date, type, detail, minutes, calories, meta:{}}
    weight: []    // {id, date, kg}
  };

  function loadState() {
    try {
      const raw = localStorage.getItem(STORAGE_KEY);
      if (!raw) return structuredClone(defaultState);
      const parsed = JSON.parse(raw);
      return Object.assign(structuredClone(defaultState), parsed);
    } catch (e) {
      console.error("Repent: failed to load state, starting fresh.", e);
      return structuredClone(defaultState);
    }
  }

  function saveState() {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
    } catch (e) {
      console.error("Repent: failed to save state.", e);
      alert("Couldn't save — your browser storage may be full or blocked.");
    }
  }

  let state = loadState();

  // ---------------------------------------------------------------------
  // MET (Metabolic Equivalent of Task) TABLES
  // Source basis: Compendium of Physical Activities, standard published
  // MET values used by fitness trackers. kcal = MET * weight(kg) * hours.
  // ---------------------------------------------------------------------
  const RUN_MET_CURVE = [
    [3.0, 4.3], [4.0, 6.0], [5.0, 8.3], [6.0, 9.8],
    [7.0, 11.0], [8.0, 11.8], [9.0, 12.8], [10.0, 14.5], [12.0, 19.0]
  ];

  function runningMET(paceMph) {
    if (!isFinite(paceMph) || paceMph <= 0) return 0;
    const curve = RUN_MET_CURVE;
    if (paceMph <= curve[0][0]) return curve[0][1];
    if (paceMph >= curve[curve.length - 1][0]) return curve[curve.length - 1][1];
    for (let i = 0; i < curve.length - 1; i++) {
      const [p1, m1] = curve[i];
      const [p2, m2] = curve[i + 1];
      if (paceMph >= p1 && paceMph <= p2) {
        const t = (paceMph - p1) / (p2 - p1);
        return m1 + t * (m2 - m1);
      }
    }
    return curve[curve.length - 1][1];
  }

  const MET = {
    basketball: { casual: 4.5, pickup: 6.5, competitive: 8.0 },
    pickleball: { recreational: 4.5, competitive: 5.0 },
    lifting: { light: 3.5, moderate: 5.0, vigorous: 6.0 },
    other: { light: 4.0, moderate: 6.0, vigorous: 8.0 }
  };

  function kcalFromMET(met, weightKg, minutes) {
    if (!weightKg || weightKg <= 0) weightKg = 70; // sensible fallback if no profile set
    return met * weightKg * (minutes / 60);
  }

  function currentWeightKg() {
    // Prefer the most recent weigh-in; fall back to profile weight.
    if (state.weight.length) {
      const sorted = [...state.weight].sort((a, b) => b.date.localeCompare(a.date));
      return sorted[0].kg;
    }
    return state.profile.weightKg || 70;
  }

  // ---------------------------------------------------------------------
  // FORMATTERS (display-unit aware)
  // ---------------------------------------------------------------------
  function fmtWeightKg(kg, decimals = 1) {
    if (kg == null || !isFinite(kg)) return "—";
    const val = state.profile.units === "metric" ? kg : kgToLb(kg);
    return val.toFixed(decimals);
  }
  function weightUnitLabel() { return state.profile.units === "metric" ? "kg" : "lb"; }
  function distUnitLabel() { return state.profile.units === "metric" ? "km" : "mi"; }
  function fmtDistMiles(mi, decimals = 2) {
    if (mi == null || !isFinite(mi)) return "0.0";
    const val = state.profile.units === "metric" ? (mi / MI_PER_KM) : mi;
    return val.toFixed(decimals);
  }
  function fmtLoadLb(lb) {
    if (lb == null || !isFinite(lb)) return "—";
    const val = state.profile.units === "metric" ? lbToKg(lb) : lb;
    return Math.round(val).toLocaleString();
  }

  // ---------------------------------------------------------------------
  // SLEEP DURATION — robust overnight handling
  // ---------------------------------------------------------------------
  function sleepHours(dateStr, bedtime, wake) {
    const bed = new Date(`${dateStr}T${bedtime}:00`);
    let wakeDt = new Date(`${dateStr}T${wake}:00`);
    if (wakeDt.getTime() <= bed.getTime()) {
      wakeDt = new Date(wakeDt.getTime() + 24 * 3600 * 1000);
    }
    const hours = (wakeDt - bed) / 3600000;
    return Math.round(hours * 100) / 100;
  }

  // ---------------------------------------------------------------------
  // DATE HELPERS
  // ---------------------------------------------------------------------
  function daysAgoStr(n) {
    const d = new Date();
    d.setDate(d.getDate() - n);
    return localDateStr(d);
  }
  function isWithinLastDays(dateStr, n) {
    return dateStr >= daysAgoStr(n - 1);
  }
  function fmtDateHuman(dateStr) {
    const d = new Date(`${dateStr}T00:00:00`);
    return d.toLocaleDateString(undefined, { month: "short", day: "numeric", year: "numeric" });
  }

  // ---------------------------------------------------------------------
  // NAVIGATION
  // ---------------------------------------------------------------------
  const navButtons = document.querySelectorAll(".nav__item");
  navButtons.forEach((btn) => {
    btn.addEventListener("click", () => {
      navButtons.forEach((b) => b.classList.remove("is-active"));
      btn.classList.add("is-active");
      document.querySelectorAll(".view").forEach((v) => v.classList.remove("is-active"));
      document.getElementById(`view-${btn.dataset.view}`).classList.add("is-active");
      if (btn.dataset.view === "dashboard") renderDashboard();
      if (btn.dataset.view === "sleep") renderSleep();
      if (btn.dataset.view === "exercise") renderExercise();
      if (btn.dataset.view === "weight") renderWeight();
    });
  });

  // ---------------------------------------------------------------------
  // MODALS
  // ---------------------------------------------------------------------
  function openModal(id) { document.getElementById(id).classList.add("is-open"); }
  function closeModal(id) { document.getElementById(id).classList.remove("is-open"); }
  document.querySelectorAll("[data-close]").forEach((btn) => {
    btn.addEventListener("click", () => closeModal(btn.dataset.close));
  });
  document.querySelectorAll(".modal-backdrop").forEach((bd) => {
    bd.addEventListener("click", (e) => { if (e.target === bd) bd.classList.remove("is-open"); });
  });

  // ---------------------------------------------------------------------
  // SLEEP FORM
  // ---------------------------------------------------------------------
  const sleepForm = document.getElementById("sleepForm");
  document.getElementById("openSleepForm").addEventListener("click", () => {
    document.getElementById("sleepDate").value = todayStr();
    document.getElementById("sleepBedtime").value = "23:00";
    document.getElementById("sleepWake").value = "07:00";
    document.getElementById("sleepQuality").value = 3;
    document.getElementById("sleepQualityOut").textContent = "3";
    updateSleepPreview();
    openModal("sleepModal");
  });
  ["sleepDate", "sleepBedtime", "sleepWake"].forEach((id) => {
    document.getElementById(id).addEventListener("input", updateSleepPreview);
  });
  document.getElementById("sleepQuality").addEventListener("input", (e) => {
    document.getElementById("sleepQualityOut").textContent = e.target.value;
  });
  function updateSleepPreview() {
    const date = document.getElementById("sleepDate").value;
    const bed = document.getElementById("sleepBedtime").value;
    const wake = document.getElementById("sleepWake").value;
    const el = document.getElementById("sleepDurationPreview");
    if (date && bed && wake) {
      const h = sleepHours(date, bed, wake);
      el.textContent = `That's ${h.toFixed(2)} hours of sleep.`;
    } else {
      el.textContent = "";
    }
  }
  sleepForm.addEventListener("submit", (e) => {
    e.preventDefault();
    const date = document.getElementById("sleepDate").value;
    const bedtime = document.getElementById("sleepBedtime").value;
    const wake = document.getElementById("sleepWake").value;
    const quality = Number(document.getElementById("sleepQuality").value);
    const hours = sleepHours(date, bedtime, wake);
    state.sleep.push({ id: uid(), date, bedtime, wake, hours, quality });
    saveState();
    closeModal("sleepModal");
    sleepForm.reset();
    renderAll();
  });

  // ---------------------------------------------------------------------
  // EXERCISE FORM
  // ---------------------------------------------------------------------
  const exerciseForm = document.getElementById("exerciseForm");
  const exTypeSelect = document.getElementById("exType");

  function showExerciseBlock(type) {
    document.querySelectorAll(".form-block").forEach((b) => b.classList.remove("is-visible"));
    const block = document.querySelector(`.form-block[data-block="${type}"]`);
    if (block) block.classList.add("is-visible");
  }
  exTypeSelect.addEventListener("change", () => {
    showExerciseBlock(exTypeSelect.value);
    updateCaloriePreview();
  });

  document.getElementById("openExerciseForm").addEventListener("click", () => {
    exerciseForm.reset();
    document.getElementById("exDate").value = todayStr();
    exTypeSelect.value = "running";
    showExerciseBlock("running");
    updateCaloriePreview();
    openModal("exerciseModal");
  });

  // live previews
  const exerciseInputs = [
    "runDistance", "runDuration", "bballDuration", "bballIntensity",
    "pbDuration", "pbSwings", "pbIntensity",
    "liftDuration", "liftSets", "liftReps", "liftWeight", "liftIntensity",
    "otherDuration", "otherIntensity"
  ];
  exerciseInputs.forEach((id) => {
    document.getElementById(id).addEventListener("input", updateCaloriePreview);
  });

  function computeExercisePreview() {
    const type = exTypeSelect.value;
    const weightKg = currentWeightKg();
    let minutes = 0, calories = 0, detail = "", meta = {};

    if (type === "running") {
      const dist = Number(document.getElementById("runDistance").value) || 0;
      minutes = Number(document.getElementById("runDuration").value) || 0;
      const hours = minutes / 60;
      const pace = hours > 0 ? dist / hours : 0;
      const met = runningMET(pace);
      calories = kcalFromMET(met, weightKg, minutes);
      detail = `${dist.toFixed(2)} mi`;
      meta = { distanceMi: dist, paceMph: pace };
      const pacePreview = document.getElementById("runPacePreview");
      if (pacePreview) {
        pacePreview.textContent = (dist > 0 && minutes > 0)
          ? `Pace: ${pace.toFixed(2)} mph · ${(minutes / dist).toFixed(1)} min/mi`
          : "";
      }
    } else if (type === "basketball") {
      minutes = Number(document.getElementById("bballDuration").value) || 0;
      const intensity = document.getElementById("bballIntensity").value;
      const met = MET.basketball[intensity];
      calories = kcalFromMET(met, weightKg, minutes);
      detail = intensity;
    } else if (type === "pickleball") {
      minutes = Number(document.getElementById("pbDuration").value) || 0;
      const swings = Number(document.getElementById("pbSwings").value) || 0;
      const intensity = document.getElementById("pbIntensity").value;
      const met = MET.pickleball[intensity];
      calories = kcalFromMET(met, weightKg, minutes);
      detail = `${swings} swings`;
      meta = { swings };
    } else if (type === "lifting") {
      minutes = Number(document.getElementById("liftDuration").value) || 0;
      const sets = Number(document.getElementById("liftSets").value) || 0;
      const reps = Number(document.getElementById("liftReps").value) || 0;
      const weightLb = Number(document.getElementById("liftWeight").value) || 0;
      const intensity = document.getElementById("liftIntensity").value;
      const met = MET.lifting[intensity];
      calories = kcalFromMET(met, weightKg, minutes);
      const volume = sets * reps * weightLb;
      const name = document.getElementById("liftName").value.trim();
      detail = name || "Lifting session";
      meta = { sets, reps, weightLb, volumeLb: volume };
      const volPreview = document.getElementById("liftVolumePreview");
      if (volPreview) {
        volPreview.textContent = volume > 0
          ? `Total volume: ${Math.round(volume).toLocaleString()} lb (sets × reps × weight)`
          : "";
      }
    } else if (type === "other") {
      minutes = Number(document.getElementById("otherDuration").value) || 0;
      const intensity = document.getElementById("otherIntensity").value;
      const met = MET.other[intensity];
      calories = kcalFromMET(met, weightKg, minutes);
      const name = document.getElementById("otherName").value.trim();
      detail = name || "Cardio session";
    }
    return { type, minutes, calories: Math.round(calories), detail, meta };
  }

  function updateCaloriePreview() {
    const result = computeExercisePreview();
    const el = document.getElementById("caloriePreview");
    el.textContent = result.minutes > 0
      ? `Estimated burn: ${result.calories} kcal`
      : "Enter duration to estimate calories burned.";
  }

  exerciseForm.addEventListener("submit", (e) => {
    e.preventDefault();
    const date = document.getElementById("exDate").value;
    const result = computeExercisePreview();
    if (!result.minutes || result.minutes <= 0) {
      alert("Add a duration greater than 0 minutes.");
      return;
    }
    state.exercise.push({
      id: uid(), date, type: result.type, detail: result.detail,
      minutes: result.minutes, calories: result.calories, meta: result.meta
    });
    saveState();
    closeModal("exerciseModal");
    exerciseForm.reset();
    renderAll();
  });

  // ---------------------------------------------------------------------
  // WEIGHT FORM
  // ---------------------------------------------------------------------
  const weightForm = document.getElementById("weightForm");
  document.getElementById("openWeightForm").addEventListener("click", () => {
    weightForm.reset();
    document.getElementById("weightDate").value = todayStr();
    openModal("weightModal");
  });
  weightForm.addEventListener("submit", (e) => {
    e.preventDefault();
    const date = document.getElementById("weightDate").value;
    const raw = Number(document.getElementById("weightValue").value);
    if (!raw || raw <= 0) return;
    const kg = state.profile.units === "metric" ? raw : lbToKg(raw);
    state.weight.push({ id: uid(), date, kg });
    saveState();
    closeModal("weightModal");
    weightForm.reset();
    renderAll();
  });

  // ---------------------------------------------------------------------
  // SETTINGS / PROFILE
  // ---------------------------------------------------------------------
  const profileForm = document.getElementById("profileForm");
  const unitsSelect = document.getElementById("unitsSelect");
  const profileWeightInput = document.getElementById("profileWeight");

  function loadProfileIntoForm() {
    unitsSelect.value = state.profile.units;
    if (state.profile.weightKg) {
      profileWeightInput.value = state.profile.units === "metric"
        ? state.profile.weightKg.toFixed(1)
        : kgToLb(state.profile.weightKg).toFixed(1);
    }
    document.getElementById("profileName").value = state.profile.name || "";
    refreshUnitLabels();
  }

  function refreshUnitLabels() {
    document.querySelectorAll(".unit-mi").forEach((el) => el.textContent = distUnitLabel());
    document.querySelectorAll(".unit-lb").forEach((el) => el.textContent = weightUnitLabel());
  }

  profileForm.addEventListener("submit", (e) => {
    e.preventDefault();
    const units = unitsSelect.value;
    const rawWeight = Number(profileWeightInput.value);
    state.profile.units = units;
    if (rawWeight > 0) {
      state.profile.weightKg = units === "metric" ? rawWeight : lbToKg(rawWeight);
    }
    state.profile.name = document.getElementById("profileName").value.trim();
    saveState();
    refreshUnitLabels();
    renderAll();
    const btn = profileForm.querySelector("button");
    const original = btn.textContent;
    btn.textContent = "Saved ✓";
    setTimeout(() => (btn.textContent = original), 1400);
  });

  document.getElementById("resetBtn").addEventListener("click", () => {
    if (confirm("This permanently erases all Repent data stored in this browser. Continue?")) {
      localStorage.removeItem(STORAGE_KEY);
      state = structuredClone(defaultState);
      loadProfileIntoForm();
      renderAll();
    }
  });

  document.getElementById("exportBtn").addEventListener("click", () => {
    const blob = new Blob([JSON.stringify(state, null, 2)], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `repent-export-${todayStr()}.json`;
    a.click();
    URL.revokeObjectURL(url);
  });

  // ---------------------------------------------------------------------
  // STREAK / FLAME
  // ---------------------------------------------------------------------
  function activeDatesSet() {
    const s = new Set();
    state.sleep.forEach((e) => s.add(e.date));
    state.exercise.forEach((e) => s.add(e.date));
    return s;
  }
  function computeStreak() {
    const dates = activeDatesSet();
    let streak = 0;
    let cursor = new Date();
    // if nothing logged today yet, streak still counts back from yesterday
    if (!dates.has(todayStr())) {
      cursor.setDate(cursor.getDate() - 1);
    }
    while (true) {
      const ds = localDateStr(cursor);
      if (dates.has(ds)) {
        streak++;
        cursor.setDate(cursor.getDate() - 1);
      } else break;
    }
    return streak;
  }
  function renderFlame() {
    const streak = computeStreak();
    document.getElementById("streakCount").textContent = streak;
    const t = clamp(streak / 30, 0, 1);
    const scale = 0.55 + t * 0.85;
    // interpolate color: dim ember -> bright gold
    const from = [90, 58, 42];   // dim ember rgb
    const to = [255, 193, 94];   // gold-soft rgb
    const rgb = from.map((c, i) => Math.round(c + (to[i] - c) * t));
    const flameEl = document.getElementById("flameMeter");
    flameEl.style.setProperty("--flame-scale", scale.toFixed(2));
    flameEl.style.setProperty("--flame-color", `rgb(${rgb.join(",")})`);
  }

  // ---------------------------------------------------------------------
  // CHARTS (Chart.js) — themed to match palette
  // ---------------------------------------------------------------------
  const chartInstances = {};
  const CHART_TEXT = "#B8AD9A";
  const CHART_GRID = "rgba(242,235,221,0.07)";
  Chart.defaults.font.family = "'Inter', sans-serif";
  Chart.defaults.color = CHART_TEXT;

  function upsertChart(id, config) {
    if (chartInstances[id]) chartInstances[id].destroy();
    const ctx = document.getElementById(id).getContext("2d");
    chartInstances[id] = new Chart(ctx, config);
    return chartInstances[id];
  }

  function baseLineOptions() {
    return {
      responsive: true,
      maintainAspectRatio: false,
      plugins: { legend: { display: false } },
      scales: {
        x: { grid: { display: false }, ticks: { color: CHART_TEXT, font: { size: 11 } } },
        y: { grid: { color: CHART_GRID }, ticks: { color: CHART_TEXT, font: { size: 11 } }, beginAtZero: true }
      }
    };
  }

  // ---------------------------------------------------------------------
  // RENDER: DASHBOARD
  // ---------------------------------------------------------------------
  function renderDashboard() {
    document.getElementById("todayDate").textContent = new Date().toLocaleDateString(undefined, {
      weekday: "long", month: "long", day: "numeric"
    });

    const today = todayStr();
    const caloriesToday = state.exercise
      .filter((e) => e.date === today)
      .reduce((sum, e) => sum + e.calories, 0);
    document.getElementById("statCaloriesToday").textContent = Math.round(caloriesToday).toLocaleString();

    const lastSleep = [...state.sleep].sort((a, b) => b.date.localeCompare(a.date))[0];
    document.getElementById("statSleepLast").textContent = lastSleep ? lastSleep.hours.toFixed(1) : "—";

    const sessionsWeek = state.exercise.filter((e) => isWithinLastDays(e.date, 7)).length;
    document.getElementById("statSessionsWeek").textContent = sessionsWeek;

    const wKg = currentWeightKg();
    document.getElementById("statWeightCurrent").textContent = state.weight.length || state.profile.weightKg
      ? fmtWeightKg(wKg) : "—";
    document.getElementById("statWeightUnit").textContent = weightUnitLabel();

    // weekly calories bar chart (last 7 days)
    const labels = [];
    const data = [];
    for (let i = 6; i >= 0; i--) {
      const ds = daysAgoStr(i);
      labels.push(new Date(`${ds}T00:00:00`).toLocaleDateString(undefined, { weekday: "short" }));
      const dayCal = state.exercise.filter((e) => e.date === ds).reduce((s, e) => s + e.calories, 0);
      data.push(Math.round(dayCal));
    }
    upsertChart("weekChart", {
      type: "bar",
      data: { labels, datasets: [{ data, backgroundColor: "#C1421A", borderRadius: 5, maxBarThickness: 34 }] },
      options: baseLineOptions()
    });

    // ledger by activity type, this week
    const weekEx = state.exercise.filter((e) => isWithinLastDays(e.date, 7));
    const totalsByType = {};
    weekEx.forEach((e) => { totalsByType[e.type] = (totalsByType[e.type] || 0) + e.calories; });
    const maxVal = Math.max(1, ...Object.values(totalsByType));
    const typeLabels = { running: "Running", basketball: "Basketball", pickleball: "Pickleball", lifting: "Lifting", other: "Other" };
    const ledger = document.getElementById("activityLedger");
    ledger.innerHTML = "";
    if (Object.keys(totalsByType).length === 0) {
      ledger.innerHTML = `<p class="empty-state">Nothing logged this week yet.</p>`;
    } else {
      Object.entries(totalsByType).sort((a, b) => b[1] - a[1]).forEach(([type, val]) => {
        const row = document.createElement("div");
        row.className = "ledger__row";
        row.innerHTML = `
          <span class="ledger__label">${typeLabels[type] || type}</span>
          <span class="ledger__bar-track"><span class="ledger__bar-fill" style="width:${(val / maxVal) * 100}%"></span></span>
          <span class="ledger__value">${Math.round(val)}</span>
        `;
        ledger.appendChild(row);
      });
    }

    // recent feed (mixed, latest 8)
    const icons = { running: "🏃", basketball: "🏀", pickleball: "🎾", lifting: "🏋️", other: "⚡", sleep: "🌙", weight: "⚖️" };
    const feedItems = [
      ...state.exercise.map((e) => ({ kind: e.type, date: e.date, title: `${typeLabels[e.type] || e.type} — ${e.detail}`, meta: `${e.minutes} min`, value: `${e.calories} kcal` })),
      ...state.sleep.map((s) => ({ kind: "sleep", date: s.date, title: "Sleep logged", meta: `Quality ${s.quality}/5`, value: `${s.hours.toFixed(1)} h` })),
      ...state.weight.map((w) => ({ kind: "weight", date: w.date, title: "Weigh-in", meta: "", value: `${fmtWeightKg(w.kg)} ${weightUnitLabel()}` }))
    ].sort((a, b) => b.date.localeCompare(a.date)).slice(0, 8);

    const feed = document.getElementById("recentFeed");
    feed.innerHTML = "";
    if (!feedItems.length) {
      feed.innerHTML = `<p class="empty-state">Log your first entry to break ground.</p>`;
    } else {
      feedItems.forEach((item) => {
        const row = document.createElement("div");
        row.className = "feed__row";
        row.innerHTML = `
          <span class="feed__icon">${icons[item.kind] || "•"}</span>
          <span class="feed__body">
            <span class="feed__title">${item.title}</span>
            <span class="feed__meta">${fmtDateHuman(item.date)}${item.meta ? " · " + item.meta : ""}</span>
          </span>
          <span class="feed__value">${item.value}</span>
        `;
        feed.appendChild(row);
      });
    }

    renderFlame();
  }

  // ---------------------------------------------------------------------
  // RENDER: SLEEP
  // ---------------------------------------------------------------------
  function renderSleep() {
    const sorted = [...state.sleep].sort((a, b) => b.date.localeCompare(a.date));
    const last7 = sorted.filter((s) => isWithinLastDays(s.date, 7));
    const avg7 = last7.length ? last7.reduce((s, e) => s + e.hours, 0) / last7.length : null;
    document.getElementById("sleepAvg7").textContent = avg7 != null ? avg7.toFixed(1) : "—";
    const best = sorted.length ? Math.max(...sorted.map((s) => s.hours)) : null;
    document.getElementById("sleepBest").textContent = best != null ? best.toFixed(1) : "—";
    const consistency = last7.filter((s) => s.hours >= 7).length;
    document.getElementById("sleepConsistency").textContent = last7.length ? `${consistency}` : "—";
    const qAvg = last7.length ? (last7.reduce((s, e) => s + e.quality, 0) / last7.length) : null;
    document.getElementById("sleepQualityAvg").textContent = qAvg != null ? qAvg.toFixed(1) : "—";

    // trend chart, last 14 nights chronological
    const last14 = [...state.sleep].sort((a, b) => a.date.localeCompare(b.date)).filter((s) => isWithinLastDays(s.date, 14));
    upsertChart("sleepChart", {
      type: "line",
      data: {
        labels: last14.map((s) => fmtDateHuman(s.date)),
        datasets: [{
          data: last14.map((s) => s.hours),
          borderColor: "#E8672E", backgroundColor: "rgba(232,103,46,0.15)",
          fill: true, tension: 0.35, pointBackgroundColor: "#FFC15E", pointRadius: 3
        }]
      },
      options: baseLineOptions()
    });

    const tbody = document.querySelector("#sleepTable tbody");
    tbody.innerHTML = "";
    document.getElementById("sleepEmpty").style.display = sorted.length ? "none" : "block";
    sorted.forEach((s) => {
      const tr = document.createElement("tr");
      tr.innerHTML = `
        <td>${fmtDateHuman(s.date)}</td>
        <td>${s.bedtime}</td>
        <td>${s.wake}</td>
        <td>${s.hours.toFixed(2)} h</td>
        <td>${"★".repeat(s.quality)}${"☆".repeat(5 - s.quality)}</td>
        <td><button class="row-del" data-id="${s.id}" data-kind="sleep" title="Delete">✕</button></td>
      `;
      tbody.appendChild(tr);
    });
  }

  // ---------------------------------------------------------------------
  // RENDER: EXERCISE
  // ---------------------------------------------------------------------
  function renderExercise() {
    const weekEx = state.exercise.filter((e) => isWithinLastDays(e.date, 7));

    const milesTotal = weekEx.filter((e) => e.type === "running")
      .reduce((s, e) => s + (e.meta.distanceMi || 0), 0);
    document.getElementById("statMilesTotal").textContent = fmtDistMiles(milesTotal);

    const volumeTotal = weekEx.filter((e) => e.type === "lifting")
      .reduce((s, e) => s + (e.meta.volumeLb || 0), 0);
    document.getElementById("statVolumeTotal").textContent = fmtLoadLb(volumeTotal);

    const swingsTotal = weekEx.filter((e) => e.type === "pickleball")
      .reduce((s, e) => s + (e.meta.swings || 0), 0);
    document.getElementById("statSwingsTotal").textContent = swingsTotal.toLocaleString();

    const courtTime = weekEx.filter((e) => e.type === "basketball" || e.type === "pickleball")
      .reduce((s, e) => s + e.minutes, 0);
    document.getElementById("statCourtTime").textContent = courtTime;

    const typeLabels = { running: "Running", basketball: "Basketball", pickleball: "Pickleball", lifting: "Lifting", other: "Other" };
    const sorted = [...state.exercise].sort((a, b) => b.date.localeCompare(a.date));
    const tbody = document.querySelector("#exerciseTable tbody");
    tbody.innerHTML = "";
    document.getElementById("exerciseEmpty").style.display = sorted.length ? "none" : "block";
    sorted.forEach((e) => {
      const tr = document.createElement("tr");
      tr.innerHTML = `
        <td>${fmtDateHuman(e.date)}</td>
        <td>${typeLabels[e.type] || e.type}</td>
        <td>${e.detail}</td>
        <td>${e.minutes} min</td>
        <td>${e.calories} kcal</td>
        <td><button class="row-del" data-id="${e.id}" data-kind="exercise" title="Delete">✕</button></td>
      `;
      tbody.appendChild(tr);
    });
  }

  // ---------------------------------------------------------------------
  // RENDER: WEIGHT
  // ---------------------------------------------------------------------
  function renderWeight() {
    const sorted = [...state.weight].sort((a, b) => a.date.localeCompare(b.date));
    const latest = sorted[sorted.length - 1];
    document.getElementById("weightCurrent").textContent = latest ? fmtWeightKg(latest.kg) : "—";
    document.getElementById("weightCurrentUnit").textContent = weightUnitLabel();
    document.getElementById("weightEntries").textContent = sorted.length;
    document.getElementById("weightChangeUnit").textContent = weightUnitLabel();

    const cutoff = daysAgoStr(29);
    const past = [...sorted].reverse().find((w) => w.date <= cutoff);
    if (latest && past) {
      const deltaKg = latest.kg - past.kg;
      const displayDelta = state.profile.units === "metric" ? deltaKg : kgToLb(deltaKg);
      const sign = displayDelta > 0 ? "+" : "";
      document.getElementById("weightChange30").textContent = `${sign}${displayDelta.toFixed(1)}`;
    } else {
      document.getElementById("weightChange30").textContent = "—";
    }

    upsertChart("weightChart", {
      type: "line",
      data: {
        labels: sorted.map((w) => fmtDateHuman(w.date)),
        datasets: [{
          data: sorted.map((w) => Number(fmtWeightKg(w.kg))),
          borderColor: "#E3B23C", backgroundColor: "rgba(227,178,60,0.12)",
          fill: true, tension: 0.3, pointBackgroundColor: "#FFC15E", pointRadius: 3
        }]
      },
      options: baseLineOptions()
    });

    const tbody = document.querySelector("#weightTable tbody");
    tbody.innerHTML = "";
    document.getElementById("weightEmpty").style.display = sorted.length ? "none" : "block";
    const displayOrder = [...sorted].reverse();
    displayOrder.forEach((w, idx) => {
      const prev = displayOrder[idx + 1];
      let changeStr = "—";
      if (prev) {
        const d = state.profile.units === "metric" ? (w.kg - prev.kg) : kgToLb(w.kg - prev.kg);
        changeStr = `${d > 0 ? "+" : ""}${d.toFixed(1)}`;
      }
      const tr = document.createElement("tr");
      tr.innerHTML = `
        <td>${fmtDateHuman(w.date)}</td>
        <td>${fmtWeightKg(w.kg)} ${weightUnitLabel()}</td>
        <td>${changeStr}</td>
        <td><button class="row-del" data-id="${w.id}" data-kind="weight" title="Delete">✕</button></td>
      `;
      tbody.appendChild(tr);
    });
  }

  // ---------------------------------------------------------------------
  // DELETE (event delegation across all tables)
  // ---------------------------------------------------------------------
  document.addEventListener("click", (e) => {
    const btn = e.target.closest(".row-del");
    if (!btn) return;
    const { id, kind } = btn.dataset;
    if (kind === "sleep") state.sleep = state.sleep.filter((x) => x.id !== id);
    if (kind === "exercise") state.exercise = state.exercise.filter((x) => x.id !== id);
    if (kind === "weight") state.weight = state.weight.filter((x) => x.id !== id);
    saveState();
    renderAll();
  });

  // ---------------------------------------------------------------------
  // INIT
  // ---------------------------------------------------------------------
  function renderAll() {
    renderDashboard();
    renderSleep();
    renderExercise();
    renderWeight();
  }

  loadProfileIntoForm();
  showExerciseBlock("running");
  renderAll();
})();
