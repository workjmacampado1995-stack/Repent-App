# Repent — discipline, logged

A personal health tracker for sleep, exercise, weight lifting, and sport-specific
stats (running mileage, basketball, pickleball swings), with a body-weight log
and accurate calorie-burn math. Pure HTML/CSS/JS — no build step, no framework,
no account. Your data stays in your browser.

## Run it in VS Code

1. Open this folder (`repent-app`) in VS Code.
2. Install the **Live Server** extension (by Ritwick Dey) if you don't have it.
3. Right-click `index.html` → **Open with Live Server**.

That's it — no `npm install`, no build step. (You can also just double-click
`index.html` to open it directly in a browser, though Live Server gives you
auto-reload while you tinker with the code.)

## What it tracks

- **Sleep** — bedtime/wake time → duration (handles overnight crossing
  midnight correctly), sleep quality (1–5), 7-night average, consistency.
- **Exercise**
  - **Running** — distance + duration → pace (mph) → calories, using a
    pace-based MET interpolation table (faster pace = higher MET, matching
    how real energy expenditure scales with running speed).
  - **Basketball** — duration + intensity (casual / pickup / competitive).
  - **Pickleball** — duration, swing count, and intensity. Swings are tracked
    as their own stat; calories still come from validated MET tables (swing
    count alone isn't a reliable calorie proxy, so it's kept as what it is —
    an activity stat, not a calorie input).
  - **Weight lifting** — sets, reps, average load, and effort level. Volume
    (sets × reps × weight) is calculated precisely; calories use MET values
    for light/moderate/vigorous resistance training.
  - **Other cardio** — anything else, with an intensity-based MET estimate.
- **Body weight** — log entries over time, with a trend chart and 30-day
  change. Your most recent weigh-in (or your profile weight, if you haven't
  logged one) is what calorie math uses — real body weight changes real
  energy expenditure.

## The math, precisely

All calorie estimates use the standard formula from the Compendium of
Physical Activities:

```
calories = MET × body weight (kg) × duration (hours)
```

Running's MET value isn't a flat number — it's interpolated from a
pace-to-MET curve (breakpoints at 3–12 mph) so a 6 mph jog and a 9 mph tempo
run are weighted correctly instead of being treated the same.

All values are stored internally in one canonical unit (kilograms for
weight, miles for distance, pounds for lifting load) and converted only at
display time, so switching units in Settings never compounds rounding error
into your history.

## Data & privacy

Everything is stored in `localStorage` in your browser — nothing is sent
anywhere. Use **Export data** on the Dashboard to download a JSON backup, or
**Settings → Erase all data** to wipe it. Because it's local, the data won't
follow you to a different browser or device unless you export/import
manually.

## File structure

```
repent-app/
├── index.html       structure + all modals/forms
├── css/style.css     design system (dark ember/candlelight theme)
├── js/app.js         state, calculations, rendering, charts
└── README.md
```

No dependencies to install — Chart.js is loaded from a CDN `<script>` tag in
`index.html`.
